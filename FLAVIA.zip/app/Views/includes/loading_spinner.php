<!-- Loader -->
<div id="loading-spinner">
    <div class="spinner">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>