<!-- Loader -->
<div id="loading-spinner">
    <div class="spinner"></div>
</div>