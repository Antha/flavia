<div id="footer" class="footer-style">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center p-3 footer-wrapper">
                <span>Copyright © 2025. All rights reserved by SRM</span>
            </div>
        </div>
    </div>
</div>